-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 07 feb 2024 om 09:40
-- Serverversie: 8.0.31
-- PHP-versie: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbblogoop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `photo_id` int NOT NULL,
  `user_id` int NOT NULL,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `comments`
--

INSERT INTO `comments` (`id`, `photo_id`, `user_id`, `author`, `body`) VALUES
(1, 13, 1, 'Tom', 'test tekst'),
(2, 13, 1, 'Tom', 'test tekst'),
(3, 13, 1, 'Tom', 'test tekst'),
(4, 13, 1, 'Emmeline', 'test'),
(5, 13, 1, 'Emmeline', 'test'),
(6, 13, 1, 'Emmeline', 'test');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int NOT NULL,
  `alternate_text` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `description`, `filename`, `type`, `size`, `alternate_text`, `deleted_at`) VALUES
(1, 'Photo Belgium', 'Lorem ipsum', 'page2024_01_22-10-22-15.png', 'jpg', 35, '', '2024-01-18 11:27:05'),
(2, 'Tom', 'Lorem ipsum', 'image.jpg', 'jpg', 15, '', '2024-01-18 14:11:13'),
(3, 'natuurbeelds', '                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                image natuur water paars    sss                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 40053, 'ss', '0000-00-00 00:00:00'),
(4, 'natuurbeeld', 'image natuur water paars', 'page2024_01_22-10-22-15.png', 'image/jpeg', 204301, '', '2024-01-18 14:11:30'),
(5, 'natuurbeelds', '                                                                                                                                                                                                                                                                                                image natuur water paars    sss                                                                                                                                                                                                                                                                    ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 40053, 'ss', '0000-00-00 00:00:00'),
(6, 'ddgfdgf', 'fdgf', 'page2024_01_22-10-22-15.png', 'image/jpeg', 232821, '', '0000-00-00 00:00:00'),
(7, 'natuurbeelds', '                                                                                                                                                                                                                                                                                                                                                image natuur water paars    sss                                                                                                                                                                                                                                                                                                                ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 232821, 'ss', '0000-00-00 00:00:00'),
(8, 'natuurbeelds', '                                                                                                                                                                                                                                                                                                                                                                                                image natuur water paars    sss                                                                                                                                                                                                                                                                                                                                                            ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 156718, 'ss', '0000-00-00 00:00:00'),
(9, 'natuurbeelds', '                                                                                                                                                                                                                                                                                                                                                                                                                                                image natuur water paars    sss                                                                                                                                                                                                                                                                                                                                                                                                        ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 40053, 'ss', '0000-00-00 00:00:00'),
(10, 'natuurbeelds', '                                                                                                                                                                                                                                                                                                                                                                                                                                                image natuur water paars    sss                                                                                                                                                                                                                                                                                                                                                                                                        ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 40053, 'ss', '0000-00-00 00:00:00'),
(11, 'natuurbeelds', '                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                image natuur water paars    sss                                                                                                                                                                                                                                                                                                                                                                                                                                                    ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 261957, 'ss', '0000-00-00 00:00:00'),
(12, 'nieuw', 'nieuw', 'fisherman-sri-lanka2024_01_22-10-04-11.jpg', 'image/jpeg', 156718, '', '0000-00-00 00:00:00'),
(13, 'nieuw', 'nieuw', 'fisherman-sri-lanka2024_01_22-10-08-54.jpg', 'image/jpeg', 156718, '', NULL),
(14, 'ddddsdsf', '      dsfdf       dsfdsf         dsfdf                     dfdfssdf                                                                                                     dd                                                                                                                                    ', 'page2024_01_22-10-22-15.png', 'image/jpeg', 232821, '', NULL),
(15, 'sdfsd', 'dsdsf', 'page2024_01_22-10-22-15.png', 'image/png', 997555, '', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `user_image`, `deleted_at`) VALUES
(1, 'admin', '$2b$12$RzCMOSqUcbsACB7QC7oIo.a.Q6.FvV1Bixgo6Yr9g//oUH6mcQC36', 'Tom', 'Vanhoutte', 'hond2024_01_23-10-55-11.jpg', '2024-01-25 11:27:49'),
(3, 'tests', 'test', 'tests', 'tests', 'image102024_01_23-10-56-46.jpg', '2024-01-23 12:30:19'),
(4, 'testdsffsdsdf', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(5, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(6, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(7, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(8, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(9, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(10, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(11, 'username', 'pwd', 'first_name', 'last_name', '', '0000-00-00 00:00:00'),
(12, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(13, 'test', 'test', 'test', 'test', '', '0000-00-00 00:00:00'),
(14, 'nieuwetest', 'nieuwetest', 'nieuwetest', 'nieuwetest', 'image102024_01_23-10-33-09.jpg', '0000-00-00 00:00:00'),
(15, 'Tom', '$2y$10$eXNZvkfB.NFjXYeOka2E0OwmCBNUgh071usA.F2iiPA/.ayLNLWz.', 'Tom', 'Vanhoutte', 'image102024_01_23-14-05-20.jpg', '0000-00-00 00:00:00'),
(16, 'Tim', '$2y$10$sDzDWPwBX.gEQUZVzX/7s.2BHXmN04w6o1YYMajIFjloPa7l6SIiy', 'Tim', 'Tim', 'image102024_01_23-14-40-04.jpg', '0000-00-00 00:00:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
